// counterexample_finder.cpp
#include <iostream>
#include <vector>
#include <algorithm>
#include <set>
#include <fstream>
#include <string>
#include <functional>
using namespace std;

// ---------- 前向声明 ----------
vector<int> constructBarA(const vector<int>& A);
bool isOneStronglyExpressive(const vector<int>& barA);
bool secondaryScreen(const vector<int>& A_sorted);

// ---------- 核心函数实现 ----------
vector<int> constructBarA(const vector<int>& A) {
    int t = (int)A.size();
    vector<int> barA;
    if (t == 0) return barA;

    if (t % 2 == 0) {
        for (int i = 0; i < t; i += 2) {
            barA.push_back(A[i + 1] - A[i]);
        }
    } else {
        barA.push_back(A[0]);
        for (int i = 1; i < t; i += 2) {
            if (i + 1 < t) {
                barA.push_back(A[i + 1] - A[i]);
            }
        }
    }
    return barA;
}

bool isOneStronglyExpressive(const vector<int>& barA) {
    if (barA.empty()) return true;
    vector<int> B = barA;
    B.push_back(1);
    sort(B.begin(), B.end());
    int sum = 0;
    for (int x : B) {
        if (x > sum + 1) return false;
        sum += x;
    }
    return true;
}
bool isZeroStronglyExpressive(const vector<int>& barA) {
    if (barA.empty()) return true;
    vector<int> B = barA;
    sort(B.begin(), B.end());
    long long sum = 0;
    for (int x : B) {
        if ((long long)x > sum + 1) {
            return false;
        }
        sum += x;
    }
    return true;
}
bool GreedyScreen(const vector<int>& A_sorted) {
    if (A_sorted.empty()) return true;

    multiset<int> remaining(A_sorted.begin(), A_sorted.end());
    long long sumX = 0; 

    while (!remaining.empty()) {
       
        auto it = remaining.upper_bound(static_cast<int>(sumX + 1));
        if (it != remaining.begin()) {
            --it; 
            int a = *it;
            sumX += a;
            remaining.erase(it);
            continue;
        }

   
        vector<int> remVec(remaining.begin(), remaining.end());
        int n = remVec.size();
        int best_diff = -1;
        int x_val = -1, y_val = -1;

        
        for (int i = n - 1; i >= 1; --i) {
            for (int j = i - 1; j >= 0; --j) {
                int diff = remVec[i] - remVec[j];
                if (diff <= sumX + 1 && diff > best_diff) {
                    best_diff = diff;
                    x_val = remVec[i];
                    y_val = remVec[j];
                   
                }
            }
        }

        if (best_diff == -1) {
            
            return false;
        }

        
        sumX += best_diff;

       
        auto it_x = remaining.find(x_val);
        auto it_y = remaining.find(y_val);
        if (it_x != remaining.end() && it_y != remaining.end()) {
            remaining.erase(it_x);
            
            remaining.erase(it_y);
        } else {
           
            return false;
        }
    }

    return true; 
}
bool secondaryScreen(const vector<int>& A_sorted) {
    if (A_sorted.size() < 4) return false;

    vector<int> barA = constructBarA(A_sorted);
    if (barA.empty()) return false;

    int max_d = *max_element(barA.begin(), barA.end());
    int j = -1;
    int t = (int)A_sorted.size();

    if (t % 2 == 0) {
        for (int i = 0; i < t; i += 2) {
            if (A_sorted[i+1] - A_sorted[i] == max_d) {
                j = i + 1; break;
            }
        }
    } else {
        if (A_sorted[0] == max_d) {
            j = 0;
        } else {
            for (int i = 1; i < t; i += 2) {
                if (i+1 < t && A_sorted[i+1] - A_sorted[i] == max_d) {
                    j = i + 1; break;
                }
            }
        }
    }

    if (j == -1) return false;

    int a_prev = (j == 0) ? 0 : A_sorted[j - 1];
    int a_curr = A_sorted[j];

    vector<int> A1, A2;
    for (int a : A_sorted) {
        if (a < a_prev) A1.push_back(a);
        else if (a > a_curr) A2.push_back(a);
    }

    struct Candidate {
        int z, x, y, delta;
    };
    vector<Candidate> candidates;

    auto addCandidates = [&](const vector<int>& V) {
        int nv = (int)V.size();
        for (int i = 0; i < nv; ++i) {
            for (int j = i + 1; j < nv; ++j) {
                int x = V[j], y = V[i];
                int sum_xy = x + y;
                int diff_xy = x - y;
                candidates.push_back({sum_xy, x, y, abs(max_d - sum_xy)});
                if (diff_xy > 0) {
                    candidates.push_back({diff_xy, x, y, abs(max_d - diff_xy)});
                }
            }
        }
    };

    if (A1.size() >= 2) addCandidates(A1);
    if (A2.size() >= 2) addCandidates(A2);

    if (candidates.empty()) return false;

    sort(candidates.begin(), candidates.end(), [](const Candidate& a, const Candidate& b) {
        return a.delta < b.delta;
    });

    int K = min(5, (int)candidates.size());
    for (int idx = 0; idx < K; ++idx) {
        const Candidate& cand = candidates[idx];
        set<int> to_remove = {a_prev, a_curr, cand.x, cand.y};
        vector<int> A_new;
        for (int a : A_sorted) {
            if (to_remove.count(a)) {
                to_remove.erase(a);
            } else {
                A_new.push_back(a);
            }
        }
        int new_elem = abs(max_d - cand.z);
        if (new_elem > 0) {
            A_new.push_back(new_elem);
        }
        sort(A_new.begin(), A_new.end());
        vector<int> barA_new = constructBarA(A_new);
        if (isZeroStronglyExpressive(barA_new)) {
            return true;
        }
    }

    return false;
}

bool isLikelyGood(vector<int> A) {
    if (A.empty()){
        return true;
    }
    sort(A.begin(), A.end());
    A.erase(unique(A.begin(), A.end()), A.end());

    if (isZeroStronglyExpressive(constructBarA(A))) {
        return true;
        
    }

    vector<int> Aprime = A;
    bool removed = false;
  
    auto it = find(Aprime.begin(), Aprime.end(), 1);
    if (it != Aprime.end()) {
        Aprime.erase(it);
        removed = true;
    } else {
        for (size_t i = 0; i + 1 < A.size(); ++i) {
            if (A[i+1] - A[i] == 1) {
                Aprime.clear();
                for (size_t j = 0; j < A.size(); ++j) {
                    if (j != i && j != i+1) Aprime.push_back(A[j]);
                }
                removed = true;
                break;
            }
        }
    }
    if (removed==true & isOneStronglyExpressive(constructBarA(Aprime))) {
        return true;
   
    }

    if (secondaryScreen(A)) {
    
        return true;
       
    }
       if (GreedyScreen(A)) {
    
        return true;
       
    }
    return false;
}

// ---------- 主函数 ----------
// 修改 generate_combinations：不返回 vector，而是对每个子集调用回调函数
void generate_combinations_stream(int n, int k, const function<void(const vector<int>&)>& process) {
    vector<int> combination;
    function<void(int)> backtrack = [&](int start) {
        if ((int)combination.size() == k) {
            process(combination); // 立即处理，不存储
            return;
        }
        for (int i = start; i <= n; ++i) {
            combination.push_back(i);
            backtrack(i + 1);
            combination.pop_back();
        }
    };
    backtrack(1);
}

int main(int argc, char* argv[]) {
    if (argc != 3) {
        cerr << "Usage: " << argv[0] << " n k\n";
        cerr << "  n: universe size {1,2,...,n}\n";
        cerr << "  k: size of subset A (|A| = k)\n";
        return 1;
    }

    int n = stoi(argv[1]);
    int k = stoi(argv[2]);

    if (k < 0 || k > n) {
        cerr << "Error: k must satisfy 0 <= k <= n\n";
        return 1;
    }

   cout << "Enumerating all subsets of size " << k << " from [1, " << n << "]...\n";

    string filename = "counterexamples_n" + to_string(n) + "_k" + to_string(k) + ".txt";
    ofstream out(filename);
    if (!out.is_open()) {
        cerr << "Failed to open output file: " << filename << "\n";
        return 1;
    }

    int counterexample_count = 0;
    long long total_count = 0; // 可选：统计总数（但大n时可能溢出）

    // 流式生成并处理
    generate_combinations_stream(n, k, [&](const vector<int>& A) {
        ++total_count;
        if (!isLikelyGood(A)) {
            for (size_t i = 0; i < A.size(); ++i) {
                if (i > 0) out << " ";
                out << A[i];
            }
            out << "\n";
            ++counterexample_count;
            out.flush(); // 可选：确保及时写入（防崩溃丢失）
        }
    });

    out.close();
    cout << "Total subsets processed: " << total_count << "\n";
    cout << "Found " << counterexample_count << " candidate counterexamples.\n";
    cout << "Saved to: " << filename << "\n";
    return 0;
}